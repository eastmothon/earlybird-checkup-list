<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/Auth.php';

$pdo = get_db();
$auth = new Auth($pdo);
$auth->requireLogin();

$themesDir = __DIR__ . '/../themes';
$availableThemes = [];
if (is_dir($themesDir)) {
    foreach (scandir($themesDir) as $dir) {
        if ($dir !== '.' && $dir !== '..' && is_dir($themesDir . '/' . $dir)) {
            $availableThemes[] = $dir;
        }
    }
}

$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = 'Session security token expired. Please submit again.';
    } else {
        $siteName = trim((string)($_POST['site_name'] ?? 'My Custom Portal'));
        $activeTheme = (string)($_POST['active_theme'] ?? 'default-theme');

        if (!in_array($activeTheme, $availableThemes, true)) {
            $activeTheme = 'default-theme';
        }

        set_setting('site_name', $siteName !== '' ? $siteName : 'My Custom Portal');
        set_setting('active_theme', $activeTheme);
        $message = 'Settings updated.';
    }
}

$currentSiteName = get_setting('site_name', 'My Custom Portal');
$currentTheme = get_setting('active_theme', 'default-theme');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Settings &amp; Themes</title>
    <style>
        body { font-family: system-ui, sans-serif; margin: 0; background: #f8fafc; color: #0f172a; }
        nav { background: #1e293b; color: #fff; padding: 1rem 2rem; display: flex; justify-content: space-between; flex-wrap: wrap; }
        nav a { color: #e2e8f0; text-decoration: none; margin-left: 1rem; }
        .wrap { max-width: 720px; margin: 2rem auto; padding: 0 1rem; }
        input[type=text], select { width: 100%; padding: 0.5rem; margin: 0.3rem 0 1rem; border: 1px solid #cbd5e1; border-radius: 5px; box-sizing: border-box; }
        button { padding: 0.6rem 1.2rem; background: #2563eb; color: #fff; border: none; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>
<nav>
    <div><strong>CMS Admin</strong></div>
    <div>
        <a href="index.php">Dashboard</a>
        <a href="posts.php">Posts</a>
        <a href="settings.php">Settings &amp; Themes</a>
        <a href="../public/index.php">View Site</a>
        <a href="logout.php">Logout</a>
    </div>
</nav>
<div class="wrap">
    <h1>Site Settings &amp; Custom Themes</h1>
    <?php if ($message !== ''): ?><p style="color:#15803d;font-weight:600;"><?= e($message) ?></p><?php endif; ?>
    <?php if ($error !== ''): ?><p style="color:#dc2626;"><?= e($error) ?></p><?php endif; ?>
    <form method="POST" action="settings.php" style="background:#fff;padding:1.5rem;border-radius:8px;">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <label>Site Name</label>
        <input type="text" name="site_name" required value="<?= e($currentSiteName) ?>">

        <label>Active Theme</label>
        <select name="active_theme">
            <?php foreach ($availableThemes as $t): ?>
                <option value="<?= e($t) ?>" <?= ($currentTheme === $t) ? 'selected' : '' ?>><?= e($t) ?></option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Save Settings</button>
    </form>
</div>
</body>
</html>
