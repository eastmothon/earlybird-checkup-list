<?php
declare(strict_types=1);

class PostRepository {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function getAll(bool $onlyPublished = false): array {
        $sql = 'SELECT p.id, p.user_id, p.category_id, p.title, p.slug, p.excerpt, p.content,
                       p.featured_image, p.status, p.published_at, p.created_at,
                       c.name AS category_name, u.username AS author_name
                FROM posts p
                LEFT JOIN categories c ON p.category_id = c.id
                JOIN users u ON p.user_id = u.id';

        if ($onlyPublished) {
            $sql .= " WHERE p.status = 'published' AND (p.published_at IS NULL OR p.published_at <= NOW())";
        }
        $sql .= ' ORDER BY p.created_at DESC';

        return $this->pdo->query($sql)->fetchAll();
    }

    public function findById(int $id): ?array {
        $stmt = $this->pdo->prepare('SELECT * FROM posts WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $post = $stmt->fetch();
        return $post ?: null;
    }

    public function findPublishedBySlug(string $slug): ?array {
        $sql = "SELECT p.*, c.name AS category_name, u.username AS author_name
                FROM posts p
                LEFT JOIN categories c ON p.category_id = c.id
                JOIN users u ON p.user_id = u.id
                WHERE p.slug = :slug
                  AND p.status = 'published'
                  AND (p.published_at IS NULL OR p.published_at <= NOW())
                LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':slug' => $slug]);
        $post = $stmt->fetch();
        return $post ?: null;
    }

    public function create(array $data): int {
        $slug = unique_post_slug($this->pdo, (string)$data['title']);
        $status = in_array($data['status'] ?? '', ['draft', 'published'], true) ? $data['status'] : 'draft';
        $publishedAt = ($status === 'published') ? date('Y-m-d H:i:s') : null;

        $sql = 'INSERT INTO posts (
                    user_id, category_id, title, slug, excerpt, content,
                    featured_image, status, published_at
                ) VALUES (
                    :user_id, :category_id, :title, :slug, :excerpt, :content,
                    :featured_image, :status, :published_at
                )';

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':user_id'        => (int)$data['user_id'],
            ':category_id'    => !empty($data['category_id']) ? (int)$data['category_id'] : null,
            ':title'          => trim((string)$data['title']),
            ':slug'           => $slug,
            ':excerpt'        => trim((string)($data['excerpt'] ?? '')) !== '' ? trim((string)$data['excerpt']) : null,
            ':content'        => (string)$data['content'],
            ':featured_image' => $data['featured_image'] ?? null,
            ':status'         => $status,
            ':published_at'   => $publishedAt,
        ]);

        return (int)$this->pdo->lastInsertId();
    }

    public function update(int $id, array $data): bool {
        $existing = $this->findById($id);
        if (!$existing) {
            return false;
        }

        $slug = unique_post_slug($this->pdo, (string)$data['title'], $id);
        $status = in_array($data['status'] ?? '', ['draft', 'published'], true) ? $data['status'] : 'draft';

        $publishedAt = $existing['published_at'];
        if ($status === 'published' && $publishedAt === null) {
            $publishedAt = date('Y-m-d H:i:s');
        } elseif ($status === 'draft') {
            $publishedAt = null;
        }

        $sql = 'UPDATE posts SET
                    category_id = :category_id,
                    title = :title,
                    slug = :slug,
                    excerpt = :excerpt,
                    content = :content,
                    featured_image = :featured_image,
                    status = :status,
                    published_at = :published_at
                WHERE id = :id';

        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            ':id'             => $id,
            ':category_id'    => !empty($data['category_id']) ? (int)$data['category_id'] : null,
            ':title'          => trim((string)$data['title']),
            ':slug'           => $slug,
            ':excerpt'        => trim((string)($data['excerpt'] ?? '')) !== '' ? trim((string)$data['excerpt']) : null,
            ':content'        => (string)$data['content'],
            ':featured_image' => array_key_exists('featured_image', $data) ? $data['featured_image'] : $existing['featured_image'],
            ':status'         => $status,
            ':published_at'   => $publishedAt,
        ]);
    }

    public function delete(int $id): bool {
        $stmt = $this->pdo->prepare('DELETE FROM posts WHERE id = :id');
        return $stmt->execute([':id' => $id]);
    }
}
