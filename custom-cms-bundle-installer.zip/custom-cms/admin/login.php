<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/Auth.php';

try {
    $pdo = get_db();
} catch (Throwable $e) {
    exit('Database not configured yet. Please run <a href="../install.php">install.php</a> first.');
}

$auth = new Auth($pdo);
if ($auth->isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = 'Session expired or invalid security token. Please try signing in again.';
    } else {
        $login = (string)($_POST['login'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        if ($auth->attemptLogin($login, $password, $error)) {
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body { font-family: system-ui, sans-serif; background: #f1f5f9; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .box { background: #fff; padding: 2rem; border-radius: 8px; width: 350px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
        input { width: 100%; padding: 0.6rem; margin: 0.35rem 0 1rem; border: 1px solid #cbd5e1; border-radius: 5px; box-sizing: border-box; }
        button { width: 100%; padding: 0.7rem; background: #2563eb; color: #fff; border: none; border-radius: 5px; font-weight: 600; cursor: pointer; }
        .err { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; padding: 0.6rem; border-radius: 5px; margin-bottom: 1rem; font-size: 0.9rem; }
    </style>
</head>
<body>
<div class="box">
    <h2 style="margin-top:0;">Admin Login</h2>
    <?php if ($error !== ''): ?><div class="err"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" action="login.php">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <label>Username or Email</label>
        <input type="text" name="login" required autocomplete="username">
        <label>Password</label>
        <input type="password" name="password" required autocomplete="current-password">
        <button type="submit">Sign In</button>
    </form>
</div>
</body>
</html>
