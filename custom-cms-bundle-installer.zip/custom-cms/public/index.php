<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/PostRepository.php';
require_once __DIR__ . '/../core/ThemeEngine.php';

try {
    $pdo = get_db();
} catch (Throwable $e) {
    exit('CMS is not installed yet. Open <a href="../install.php">install.php</a> to set up.');
}

$postRepo = new PostRepository($pdo);
$activeTheme = get_setting('active_theme', 'default-theme');
$baseUrl = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/');
$theme = new ThemeEngine(__DIR__ . '/../themes', $activeTheme, $baseUrl);

$slug = isset($_GET['post']) ? trim((string)$_GET['post']) : '';

if ($slug !== '') {
    $post = $postRepo->findPublishedBySlug($slug);
    if (!$post) {
        http_response_code(404);
        exit('Post not found.');
    }
    $theme->render('post', [
        'post' => $post,
        'pageTitle' => $post['title'] . ' - ' . get_setting('site_name', 'My Custom Portal'),
    ]);
} else {
    $posts = $postRepo->getAll(true);
    $theme->render('home', [
        'posts' => $posts,
        'pageTitle' => get_setting('site_name', 'My Custom Portal'),
    ]);
}
