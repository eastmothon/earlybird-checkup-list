<?php require __DIR__ . '/header.php'; ?>

<h1>Latest Posts</h1>

<?php if (empty($posts)): ?>
    <div class="card"><p>No published posts yet. Create one in the Admin panel.</p></div>
<?php else: ?>
    <?php foreach ($posts as $post): ?>
        <article class="card">
            <h2><a href="<?= e($baseUrl) ?>/index.php?post=<?= e($post['slug']) ?>"><?= e($post['title']) ?></a></h2>
            <div class="meta">
                By <?= e($post['author_name']) ?> &bull;
                <?= e($post['category_name'] ?? 'Uncategorized') ?> &bull;
                <?= e($post['published_at'] ?? $post['created_at']) ?>
            </div>
            <?php if (!empty($post['featured_image'])): ?>
                <img class="featured" src="<?= e($baseUrl) ?>/assets/uploads/<?= e($post['featured_image']) ?>" alt="<?= e($post['title']) ?>">
            <?php endif; ?>
            <p><?= e($post['excerpt'] ?: mb_strimwidth(strip_tags($post['content']), 0, 180, '...')) ?></p>
            <a href="<?= e($baseUrl) ?>/index.php?post=<?= e($post['slug']) ?>">Read more &rarr;</a>
        </article>
    <?php endforeach; ?>
<?php endif; ?>

<?php require __DIR__ . '/footer.php'; ?>
