<?php require __DIR__ . '/header.php'; ?>

<article class="card">
    <h1><?= e($post['title']) ?></h1>
    <div class="meta">
        By <?= e($post['author_name']) ?> &bull;
        <?= e($post['category_name'] ?? 'Uncategorized') ?> &bull;
        <?= e($post['published_at'] ?? $post['created_at']) ?>
    </div>
    <?php if (!empty($post['featured_image'])): ?>
        <img class="featured" src="<?= e($baseUrl) ?>/assets/uploads/<?= e($post['featured_image']) ?>" alt="<?= e($post['title']) ?>">
    <?php endif; ?>
    <div class="content">
        <?= sanitize_rich_html($post['content']) ?>
    </div>
    <p style="margin-top:1.5rem;"><a href="<?= e($baseUrl) ?>/index.php">&larr; Back to Home</a></p>
</article>

<?php require __DIR__ . '/footer.php'; ?>
