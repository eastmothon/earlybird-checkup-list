<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? get_setting('site_name', 'My Custom Portal')) ?></title>
    <style>
        body { font-family: system-ui, -apple-system, sans-serif; margin: 0; background: #f8fafc; color: #0f172a; line-height: 1.6; }
        header { background: #b91c1c; color: #fff; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        header a { color: #fff; text-decoration: none; margin-left: 1rem; font-weight: 500; }
        main { max-width: 900px; margin: 2rem auto; padding: 0 1rem; }
        .card { background: #fff; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
        .meta { font-size: 0.875rem; color: #64748b; margin-bottom: 0.75rem; }
        .badge { display: inline-block; background: rgba(255,255,255,0.2); color: #fff; padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.8rem; }
        img.featured { max-width: 100%; height: auto; border-radius: 6px; margin: 1rem 0; }
        footer { text-align: center; padding: 2rem; color: #64748b; font-size: 0.875rem; }
    </style>
</head>
<body>
<header>
    <div><strong><?= e(get_setting('site_name', 'My Custom Portal')) ?></strong> <span class="badge"><?= e($themeName) ?></span></div>
    <nav>
        <a href="<?= e($baseUrl) ?>/index.php">Home</a>
        <a href="<?= e($baseUrl) ?>/../admin/index.php">Admin</a>
    </nav>
</header>
<main>
