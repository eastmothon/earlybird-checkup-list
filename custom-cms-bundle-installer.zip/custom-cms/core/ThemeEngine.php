<?php
declare(strict_types=1);

class ThemeEngine {
    private string $themesBasePath;
    private string $activeTheme;
    private string $baseUrl;

    public function __construct(string $themesBasePath, string $activeTheme, string $baseUrl = '') {
        $this->themesBasePath = rtrim($themesBasePath, '/');
        $cleanTheme = preg_replace('/[^a-zA-Z0-9_-]/', '', $activeTheme);
        $this->activeTheme = $cleanTheme !== '' ? (string)$cleanTheme : 'default-theme';
        $this->baseUrl = rtrim($baseUrl, '/');

        if (!is_dir($this->themesBasePath . '/' . $this->activeTheme)) {
            $this->activeTheme = 'default-theme';
        }
    }

    public function render(string $template, array $data = []): void {
        $safeTemplate = preg_replace('/[^a-zA-Z0-9_-]/', '', $template);
        $file = $this->themesBasePath . '/' . $this->activeTheme . '/' . $safeTemplate . '.php';
        $fallback = $this->themesBasePath . '/default-theme/' . $safeTemplate . '.php';

        $target = is_file($file) ? $file : $fallback;
        if (!is_file($target)) {
            http_response_code(404);
            exit('Template not found.');
        }

        $themeName = $this->activeTheme;
        $baseUrl = $this->baseUrl;
        extract($data, EXTR_SKIP);
        require $target;
    }
}
