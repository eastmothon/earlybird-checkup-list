<?php
declare(strict_types=1);

$lockFile = __DIR__ . '/storage/installed.lock';
$envFile  = __DIR__ . '/.env';

if (is_file($lockFile)) {
    http_response_code(403);
    exit('CMS is already installed. Delete storage/installed.lock only if you intend to re-run setup, and remove install.php in production.');
}

$errors = [];
$success = false;
$checks = [
    'PHP >= 8.0'        => version_compare(PHP_VERSION, '8.0.0', '>='),
    'PDO MySQL Driver'  => extension_loaded('pdo_mysql'),
    'Fileinfo Ext'      => extension_loaded('fileinfo'),
    'Root Writable'     => is_writable(__DIR__),
];

$form = [
    'db_host'    => $_POST['db_host'] ?? '127.0.0.1',
    'db_port'    => $_POST['db_port'] ?? '3306',
    'db_name'    => $_POST['db_name'] ?? 'custom_cms',
    'db_user'    => $_POST['db_user'] ?? 'root',
    'db_pass'    => $_POST['db_pass'] ?? '',
    'site_name'  => $_POST['site_name'] ?? 'My Custom Portal',
    'admin_user' => $_POST['admin_user'] ?? 'admin',
    'admin_email'=> $_POST['admin_email'] ?? '',
    'admin_pass' => $_POST['admin_pass'] ?? '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (in_array(false, $checks, true)) {
        $errors[] = 'Please resolve failed system checks before installing.';
    }

    $dbHost = trim($form['db_host']);
    $dbPort = trim($form['db_port']) ?: '3306';
    $dbName = preg_replace('/[^a-zA-Z0-9_]/', '', trim($form['db_name']));
    $dbUser = trim($form['db_user']);
    $dbPass = (string)$form['db_pass'];

    $siteName   = trim($form['site_name']) ?: 'My Custom Portal';
    $adminUser  = trim($form['admin_user']);
    $adminEmail = trim($form['admin_email']);
    $adminPass  = (string)$form['admin_pass'];

    if ($dbHost === '' || $dbName === '' || $dbUser === '') {
        $errors[] = 'Database host, database name, and database user are required.';
    }
    if ($adminUser === '' || !filter_var($adminEmail, FILTER_VALIDATE_EMAIL) || strlen($adminPass) < 8) {
        $errors[] = 'Admin username, valid email, and password (minimum 8 characters) are required.';
    }

    if (empty($errors)) {
        try {
            // 1. Connect to MySQL server (without DB first so we can auto-create DB)
            $serverDsn = "mysql:host={$dbHost};port={$dbPort};charset=utf8mb4";
            $pdo = new PDO($serverDsn, $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);

            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `{$dbName}`");

            // 2. Create Tables
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS users (
                    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) NOT NULL UNIQUE,
                    email VARCHAR(120) NOT NULL UNIQUE,
                    password_hash VARCHAR(255) NOT NULL,
                    role ENUM('admin', 'editor') DEFAULT 'editor',
                    failed_attempts INT UNSIGNED DEFAULT 0,
                    locked_until DATETIME NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");

            $pdo->exec("
                CREATE TABLE IF NOT EXISTS categories (
                    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    slug VARCHAR(120) NOT NULL UNIQUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");

            $pdo->exec("
                CREATE TABLE IF NOT EXISTS posts (
                    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    user_id INT UNSIGNED NOT NULL,
                    category_id INT UNSIGNED NULL,
                    title VARCHAR(255) NOT NULL,
                    slug VARCHAR(255) NOT NULL UNIQUE,
                    excerpt TEXT NULL,
                    content LONGTEXT NOT NULL,
                    featured_image VARCHAR(255) NULL,
                    status ENUM('draft', 'published') DEFAULT 'draft',
                    published_at DATETIME NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    CONSTRAINT fk_posts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    CONSTRAINT fk_posts_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");

            $pdo->exec("
                CREATE TABLE IF NOT EXISTS settings (
                    setting_key VARCHAR(100) PRIMARY KEY,
                    setting_value TEXT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");

            // 3. Seed Settings & Categories
            $stmtSet = $pdo->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (:k, :v) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
            $stmtSet->execute([':k' => 'site_name', ':v' => $siteName]);
            $stmtSet->execute([':k' => 'active_theme', ':v' => 'default-theme']);

            $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('General', 'general'), ('Technology', 'technology'), ('Lifestyle', 'lifestyle')");

            // 4. Create or Update Admin User
            $hash = password_hash($adminPass, PASSWORD_DEFAULT);
            $stmtUser = $pdo->prepare(
                'INSERT INTO users (username, email, password_hash, role, failed_attempts, locked_until)
                 VALUES (:u, :e, :p, "admin", 0, NULL)
                 ON DUPLICATE KEY UPDATE email = VALUES(email), password_hash = VALUES(password_hash), role = "admin", failed_attempts = 0, locked_until = NULL'
            );
            $stmtUser->execute([':u' => $adminUser, ':e' => $adminEmail, ':p' => $hash]);

            // 5. Write .env file
            $envContent = "DB_HOST={$dbHost}\nDB_PORT={$dbPort}\nDB_NAME={$dbName}\nDB_USER={$dbUser}\nDB_PASS=\"" . addslashes($dbPass) . "\"\n";
            if (file_put_contents($envFile, $envContent) === false) {
                throw new RuntimeException('Failed to write .env file.');
            }

            // 6. Create storage/sessions and lock file
            $storageDir = __DIR__ . '/storage/sessions';
            if (!is_dir($storageDir)) {
                @mkdir($storageDir, 0775, true);
            }
            file_put_contents($lockFile, 'Installed on ' . date('c'));

            $success = true;
        } catch (Throwable $e) {
            $errors[] = 'Installation Error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Custom CMS One-Click Installer</title>
    <style>
        body { font-family: system-ui, -apple-system, sans-serif; background: #f1f5f9; color: #0f172a; margin: 0; padding: 2rem 1rem; }
        .container { max-width: 620px; margin: 0 auto; background: #fff; padding: 2rem; border-radius: 10px; box-shadow: 0 4px 16px rgba(0,0,0,0.08); }
        h1 { margin-top: 0; font-size: 1.5rem; }
        h3 { margin: 1.5rem 0 0.5rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 0.35rem; font-size: 1.05rem; }
        label { display: block; font-size: 0.9rem; font-weight: 600; margin-top: 0.75rem; }
        input { width: 100%; padding: 0.55rem; margin-top: 0.25rem; border: 1px solid #cbd5e1; border-radius: 6px; box-sizing: border-box; }
        .row { display: grid; grid-template-columns: 2fr 1fr; gap: 0.75rem; }
        button { margin-top: 1.5rem; width: 100%; padding: 0.75rem; background: #2563eb; color: #fff; border: none; border-radius: 6px; font-size: 1rem; font-weight: 600; cursor: pointer; }
        .checks { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; background: #f8fafc; padding: 0.75rem; border-radius: 6px; font-size: 0.85rem; }
        .ok { color: #15803d; font-weight: 600; }
        .fail { color: #dc2626; font-weight: 600; }
        .alert-err { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; padding: 0.75rem; border-radius: 6px; margin-bottom: 1rem; }
        .alert-ok { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 1rem; border-radius: 6px; }
    </style>
</head>
<body>
<div class="container">
    <h1>Custom CMS — Web Installer</h1>

    <div class="checks">
        <?php foreach ($checks as $label => $passed): ?>
            <div><?= htmlspecialchars($label) ?>: <span class="<?= $passed ? 'ok' : 'fail' ?>"><?= $passed ? 'OK' : 'FAIL' ?></span></div>
        <?php endforeach; ?>
    </div>

    <?php if ($success): ?>
        <div class="alert-ok" style="margin-top:1.25rem;">
            <strong>Installation Complete!</strong>
            <p>Your database, <code>.env</code> configuration, and Admin account are ready.</p>
            <p><strong>Important Security Step:</strong> Please delete <code>install.php</code> from your server now.</p>
            <p>
                <a href="admin/login.php" style="display:inline-block;background:#16a34a;color:#fff;padding:0.55rem 1rem;border-radius:6px;text-decoration:none;font-weight:600;">Go to Admin Login &rarr;</a>
                <a href="public/index.php" style="display:inline-block;margin-left:0.5rem;padding:0.55rem 1rem;border-radius:6px;border:1px solid #16a34a;color:#166534;text-decoration:none;">View Portal</a>
            </p>
        </div>
    <?php else: ?>
        <?php if (!empty($errors)): ?>
            <div class="alert-err" style="margin-top:1rem;">
                <?php foreach ($errors as $err): ?><div><?= htmlspecialchars($err) ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <h3>1. Database Configuration</h3>
            <div class="row">
                <div>
                    <label>Database Host</label>
                    <input type="text" name="db_host" value="<?= htmlspecialchars($form['db_host']) ?>" required>
                </div>
                <div>
                    <label>Port</label>
                    <input type="text" name="db_port" value="<?= htmlspecialchars($form['db_port']) ?>" required>
                </div>
            </div>
            <label>Database Name (Auto-created if not exists)</label>
            <input type="text" name="db_name" value="<?= htmlspecialchars($form['db_name']) ?>" required>
            <label>Database Username</label>
            <input type="text" name="db_user" value="<?= htmlspecialchars($form['db_user']) ?>" required>
            <label>Database Password (Leave blank if none)</label>
            <input type="password" name="db_pass" value="<?= htmlspecialchars($form['db_pass']) ?>">

            <h3>2. Site &amp; Admin Account</h3>
            <label>Portal / Site Name</label>
            <input type="text" name="site_name" value="<?= htmlspecialchars($form['site_name']) ?>" required>
            <label>Admin Username</label>
            <input type="text" name="admin_user" value="<?= htmlspecialchars($form['admin_user']) ?>" required>
            <label>Admin Email</label>
            <input type="email" name="admin_email" value="<?= htmlspecialchars($form['admin_email']) ?>" required>
            <label>Admin Password (min 8 characters)</label>
            <input type="password" name="admin_pass" minlength="8" required>

            <button type="submit">Install Custom CMS Now</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
