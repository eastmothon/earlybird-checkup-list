<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/helpers.php';
require_once __DIR__ . '/../core/PostRepository.php';

$pdo = get_db();
$auth = new Auth($pdo);
$auth->requireLogin();

$postRepo = new PostRepository($pdo);
$errors = [];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Session security token expired. Please submit the form again.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'create' || $action === 'update') {
            $title = trim((string)($_POST['title'] ?? ''));
            $content = trim((string)($_POST['content'] ?? ''));
            $excerpt = trim((string)($_POST['excerpt'] ?? ''));
            $status = (string)($_POST['status'] ?? 'draft');
            $categoryId = $_POST['category_id'] ?? null;

            if ($title === '') {
                $errors[] = 'Title is required.';
            }
            if ($content === '') {
                $errors[] = 'Content is required.';
            }

            $uploadErr = null;
            $uploadedFile = upload_featured_image($_FILES['featured_image'] ?? [], $uploadErr);
            if ($uploadErr !== null) {
                $errors[] = $uploadErr;
            }

            if (empty($errors)) {
                $payload = [
                    'user_id'     => (int)$_SESSION['user_id'],
                    'category_id' => $categoryId,
                    'title'       => $title,
                    'excerpt'     => $excerpt,
                    'content'     => $content,
                    'status'      => $status,
                ];
                if ($uploadedFile !== null) {
                    $payload['featured_image'] = $uploadedFile;
                }

                if ($action === 'create') {
                    $payload['featured_image'] = $uploadedFile;
                    $postRepo->create($payload);
                    $message = 'Post created successfully.';
                } else {
                    $postId = (int)($_POST['id'] ?? 0);
                    $postRepo->update($postId, $payload);
                    $message = 'Post updated successfully.';
                }
            }
        } elseif ($action === 'delete') {
            $postId = (int)($_POST['id'] ?? 0);
            if ($postId > 0) {
                $existing = $postRepo->findById($postId);
                if ($postRepo->delete($postId)) {
                    if (!empty($existing['featured_image'])) {
                        $imgPath = __DIR__ . '/../public/assets/uploads/' . basename((string)$existing['featured_image']);
                        if (is_file($imgPath)) {
                            @unlink($imgPath);
                        }
                    }
                    $message = 'Post deleted.';
                }
            }
        }
    }
}

$editingPost = null;
if (isset($_GET['edit'])) {
    $editingPost = $postRepo->findById((int)$_GET['edit']);
}

$posts = $postRepo->getAll(false);
$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name ASC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Posts</title>
    <style>
        body { font-family: system-ui, sans-serif; margin: 0; background: #f8fafc; color: #0f172a; }
        nav { background: #1e293b; color: #fff; padding: 1rem 2rem; display: flex; justify-content: space-between; flex-wrap: wrap; }
        nav a { color: #e2e8f0; text-decoration: none; margin-left: 1rem; }
        .wrap { max-width: 960px; margin: 2rem auto; padding: 0 1rem; }
        input[type=text], select, textarea { width: 100%; padding: 0.5rem; margin: 0.3rem 0 0.9rem; border: 1px solid #cbd5e1; border-radius: 5px; box-sizing: border-box; }
        table { width: 100%; border-collapse: collapse; background: #fff; }
        th, td { border: 1px solid #e2e8f0; padding: 0.6rem; text-align: left; }
        button { padding: 0.5rem 1rem; background: #2563eb; color: #fff; border: none; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>
<nav>
    <div><strong>CMS Admin</strong></div>
    <div>
        <a href="index.php">Dashboard</a>
        <a href="posts.php">Posts</a>
        <a href="settings.php">Settings &amp; Themes</a>
        <a href="../public/index.php">View Site</a>
        <a href="logout.php">Logout</a>
    </div>
</nav>
<div class="wrap">
    <h1><?= $editingPost ? 'Edit Post' : 'Create New Post' ?></h1>

    <?php if ($message !== ''): ?><p style="color:#15803d;font-weight:600;"><?= e($message) ?></p><?php endif; ?>
    <?php foreach ($errors as $err): ?><p style="color:#dc2626;"><?= e($err) ?></p><?php endforeach; ?>

    <form method="POST" action="posts.php" enctype="multipart/form-data" style="background:#fff;padding:1.5rem;border-radius:8px;margin-bottom:2rem;">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="<?= $editingPost ? 'update' : 'create' ?>">
        <?php if ($editingPost): ?>
            <input type="hidden" name="id" value="<?= (int)$editingPost['id'] ?>">
        <?php endif; ?>

        <label>Title</label>
        <input type="text" name="title" required value="<?= e($editingPost['title'] ?? '') ?>">

        <label>Category</label>
        <select name="category_id">
            <option value="">-- None --</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= (int)$cat['id'] ?>" <?= ((int)($editingPost['category_id'] ?? 0) === (int)$cat['id']) ? 'selected' : '' ?>>
                    <?= e($cat['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Excerpt</label>
        <textarea name="excerpt" rows="2"><?= e($editingPost['excerpt'] ?? '') ?></textarea>

        <label>Content (HTML tags allowed: &lt;p&gt;, &lt;h2&gt;, &lt;ul&gt;, &lt;li&gt;, &lt;strong&gt;, &lt;a&gt;)</label>
        <textarea name="content" rows="8" required><?= e($editingPost['content'] ?? '') ?></textarea>

        <label>Featured Image (JPG, PNG, WEBP - max 3MB)</label>
        <input type="file" name="featured_image" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"><br><br>

        <label>Status</label>
        <select name="status">
            <option value="draft" <?= (($editingPost['status'] ?? '') === 'draft') ? 'selected' : '' ?>>Draft</option>
            <option value="published" <?= (($editingPost['status'] ?? '') === 'published') ? 'selected' : '' ?>>Published</option>
        </select>

        <button type="submit"><?= $editingPost ? 'Update Post' : 'Save Post' ?></button>
        <?php if ($editingPost): ?><a href="posts.php" style="margin-left:0.75rem;">Cancel</a><?php endif; ?>
    </form>

    <h2>All Posts</h2>
    <table>
        <thead>
            <tr><th>Title</th><th>Category</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach ($posts as $p): ?>
                <tr>
                    <td><?= e($p['title']) ?></td>
                    <td><?= e($p['category_name'] ?? '-') ?></td>
                    <td><?= e($p['status']) ?></td>
                    <td>
                        <a href="posts.php?edit=<?= (int)$p['id'] ?>">Edit</a>
                        <form method="POST" action="posts.php" style="display:inline;" onsubmit="return confirm('Delete this post?');">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                            <button type="submit" style="background:#dc2626;padding:0.25rem 0.6rem;margin-left:0.4rem;">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
