<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/Auth.php';

$auth = new Auth(get_db());
$auth->logout();
header('Location: login.php');
exit;
