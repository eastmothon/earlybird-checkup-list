<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/PostRepository.php';

$pdo = get_db();
$auth = new Auth($pdo);
$auth->requireLogin();

$postRepo = new PostRepository($pdo);
$posts = $postRepo->getAll(false);
$publishedCount = count(array_filter($posts, static fn(array $p): bool => $p['status'] === 'published'));
$draftCount = count($posts) - $publishedCount;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body { font-family: system-ui, sans-serif; margin: 0; background: #f8fafc; color: #0f172a; }
        nav { background: #1e293b; color: #fff; padding: 1rem 2rem; display: flex; justify-content: space-between; flex-wrap: wrap; }
        nav a { color: #e2e8f0; text-decoration: none; margin-left: 1rem; }
        .wrap { max-width: 900px; margin: 2rem auto; padding: 0 1rem; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; }
        .stat { background: #fff; padding: 1.25rem; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
    </style>
</head>
<body>
<nav>
    <div><strong>CMS Admin</strong> (<?= e($_SESSION['username'] ?? 'admin') ?>)</div>
    <div>
        <a href="index.php">Dashboard</a>
        <a href="posts.php">Posts</a>
        <a href="settings.php">Settings &amp; Themes</a>
        <a href="../public/index.php">View Site</a>
        <a href="logout.php">Logout</a>
    </div>
</nav>
<div class="wrap">
    <h1>Dashboard</h1>
    <div class="grid">
        <div class="stat"><h3>Total Posts</h3><p style="font-size:1.8rem;margin:0;"><?= count($posts) ?></p></div>
        <div class="stat"><h3>Published</h3><p style="font-size:1.8rem;margin:0;"><?= $publishedCount ?></p></div>
        <div class="stat"><h3>Drafts</h3><p style="font-size:1.8rem;margin:0;"><?= $draftCount ?></p></div>
    </div>
</div>
</body>
</html>
