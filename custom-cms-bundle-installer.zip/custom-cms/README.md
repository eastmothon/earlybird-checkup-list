# Custom CMS Web Portal (All-in-One Installer Bundle)

## One-Click Setup
1. Extract `custom-cms` into your web server root (e.g., `htdocs` or `/var/www/html`).
2. Open `http://<your-server-ip-or-localhost>/custom-cms/install.php` in your browser.
3. Fill in your MySQL details, Site Name, and Admin account, then click **Install Custom CMS Now**.
   - The installer automatically creates the database, all tables, `.env`, `storage/sessions`, and the Admin user.
4. Delete `install.php` after installation completes, then log in at `admin/login.php`.
