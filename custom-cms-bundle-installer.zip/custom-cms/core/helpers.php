<?php
declare(strict_types=1);

function create_slug(string $title): string {
    $slug = mb_strtolower(trim($title), 'UTF-8');
    $slug = preg_replace('/[^\p{L}\p{N}\s-]+/u', '', $slug);
    $slug = preg_replace('/[\s-]+/', '-', (string)$slug);
    $slug = trim((string)$slug, '-');
    return $slug !== '' ? $slug : 'post-' . time();
}

function unique_post_slug(PDO $pdo, string $title, ?int $ignoreId = null): string {
    $baseSlug = create_slug($title);
    $slug = $baseSlug;
    $counter = 1;

    while (true) {
        $sql = 'SELECT id FROM posts WHERE slug = :slug';
        $params = [':slug' => $slug];
        if ($ignoreId !== null) {
            $sql .= ' AND id != :id';
            $params[':id'] = $ignoreId;
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        if (!$stmt->fetch()) {
            return $slug;
        }
        $counter++;
        $slug = $baseSlug . '-' . $counter;
    }
}

function upload_featured_image(array $file, ?string &$error = null): ?string {
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'File upload error code: ' . (int)$file['error'];
        return null;
    }
    if (($file['size'] ?? 0) > 3 * 1024 * 1024) {
        $error = 'Image size must be 3MB or less.';
        return null;
    }

    if (!class_exists('finfo')) {
        $error = 'PHP fileinfo extension is not enabled.';
        return null;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $allowedMimes = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];

    if (!isset($allowedMimes[$mime])) {
        $error = 'Only JPG, PNG, and WEBP images are allowed.';
        return null;
    }

    $uploadDir = __DIR__ . '/../public/assets/uploads';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0775, true);
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $allowedMimes[$mime];
    $destination = $uploadDir . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        $error = 'Failed to save uploaded image. Check folder permissions on public/assets/uploads.';
        return null;
    }

    return $filename;
}
