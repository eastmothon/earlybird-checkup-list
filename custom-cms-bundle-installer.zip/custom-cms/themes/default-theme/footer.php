</main>
<footer>
    &copy; <?= date('Y') ?> <?= e(get_setting('site_name', 'My Custom Portal')) ?> &mdash; Custom CMS
</footer>
</body>
</html>
