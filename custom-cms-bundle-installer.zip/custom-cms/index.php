<?php
// Redirect root folder requests to public/index.php (or install.php if not yet installed)
if (!is_file(__DIR__ . '/.env') && is_file(__DIR__ . '/install.php')) {
    header('Location: install.php');
    exit;
}
header('Location: public/index.php');
exit;
