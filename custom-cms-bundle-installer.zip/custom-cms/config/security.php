<?php
declare(strict_types=1);

if (!ob_get_level()) {
    ob_start();
}

function cms_start_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    // Store sessions inside a dedicated writable folder so OS/XAMPP/Linux permission issues never break sessions
    $sessionDir = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'sessions';
    if (!is_dir($sessionDir)) {
        @mkdir($sessionDir, 0775, true);
    }
    if (is_dir($sessionDir) && is_writable($sessionDir)) {
        session_save_path($sessionDir);
    }

    $isHttps = (
        (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
    );

    session_name('CUSTOMCMSSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();
}

cms_start_session();

function csrf_token(): string {
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(?string $token): bool {
    if (!is_string($token) || $token === '' || empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function sanitize_rich_html(string $html): string {
    $allowed = '<p><br><h2><h3><h4><ul><ol><li><strong><em><b><i><a><blockquote><code><pre>';
    $clean = strip_tags($html, $allowed);
    $clean = preg_replace_callback('/<a\b([^>]*)>/i', static function (array $matches): string {
        $attrs = $matches[1];
        if (preg_match('/href\s*=\s*([\'"]?)\s*(javascript:|data:|vbscript:)/i', $attrs)) {
            $attrs = preg_replace('/href\s*=\s*([\'"]?).*?([\'"]|\s|$)/i', 'href="#"$3', $attrs);
        }
        return '<a' . $attrs . ' rel="noopener noreferrer">';
    }, $clean);
    return (string)$clean;
}
