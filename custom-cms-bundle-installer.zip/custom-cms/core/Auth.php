<?php
declare(strict_types=1);

class Auth {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function isLoggedIn(): bool {
        return !empty($_SESSION['user_id']) && is_numeric($_SESSION['user_id']);
    }

    public function requireLogin(string $redirectTo = 'login.php'): void {
        if (!$this->isLoggedIn()) {
            header('Location: ' . $redirectTo);
            exit;
        }
    }

    public function attemptLogin(string $login, string $password, ?string &$error = null): bool {
        $login = trim($login);
        if ($login === '' || $password === '') {
            $error = 'Please enter both username/email and password.';
            return false;
        }

        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE username = :u OR email = :e LIMIT 1');
        $stmt->execute([':u' => $login, ':e' => $login]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = 'Invalid username/email or password.';
            return false;
        }

        if (!empty($user['locked_until']) && strtotime((string)$user['locked_until']) > time()) {
            $error = 'Account temporarily locked due to too many failed attempts. Try again in 15 minutes.';
            return false;
        }

        if (!password_verify($password, (string)$user['password_hash'])) {
            $attempts = (int)$user['failed_attempts'] + 1;
            $lockUntil = null;
            if ($attempts >= 5) {
                $lockUntil = date('Y-m-d H:i:s', time() + 900);
                $attempts = 0;
            }
            $upd = $this->pdo->prepare('UPDATE users SET failed_attempts = :a, locked_until = :l WHERE id = :id');
            $upd->execute([':a' => $attempts, ':l' => $lockUntil, ':id' => $user['id']]);
            $error = 'Invalid username/email or password.';
            return false;
        }

        if (password_needs_rehash((string)$user['password_hash'], PASSWORD_DEFAULT)) {
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $this->pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :id')
                      ->execute([':h' => $newHash, ':id' => $user['id']]);
        }

        $this->pdo->prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = :id')
                  ->execute([':id' => $user['id']]);

        session_regenerate_id(true);
        $_SESSION['user_id']  = (int)$user['id'];
        $_SESSION['username'] = (string)$user['username'];
        $_SESSION['role']     = (string)$user['role'];

        return true;
    }

    public function logout(): void {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'] ?? '/',
                $params['domain'] ?? '',
                (bool)($params['secure'] ?? false),
                (bool)($params['httponly'] ?? true)
            );
        }
        session_destroy();
    }
}
